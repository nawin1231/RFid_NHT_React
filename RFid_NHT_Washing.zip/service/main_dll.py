from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import threading
import time
import winsound
import httpx
import json
import os
import sys
from sid_u861 import (
    open_net_port, close_net_port,
    inventory_g2, set_power,
    get_error_desc,
    buzzer_and_led,
    set_relay,
)

# ===== CONFIG =====
with open("readers_config.json") as f:
    ALL_READERS = json.load(f)

READER_INDEX = int(os.environ.get("READER_INDEX", "0"))
if READER_INDEX >= len(ALL_READERS):
    print(f"[ERROR] READER_INDEX={READER_INDEX} out of range")
    exit(1)

CFG                    = ALL_READERS[READER_INDEX]
READER_IP              = CFG["ip"]
READER_PORT_TCP        = 6000
READER_POWER           = CFG["power"]
READER_TYPE            = CFG["type"]      # register / pallet / washing / on_machine / completed
READER_PALLET_LOCATION = CFG.get("location")
MIN_QTY                = CFG.get("min_qty", 0)

# Cooldown settings
COOLDOWN             = 3   # วิ — กัน scan tag ซ้ำ
PALLET_IN_COOLDOWN   = 5    # วิ — รอ tag ครบ lot ก่อน confirm pallet-in
PALLET_OUT_COOLDOWN  = 30    # วิ — tag หาย นานเกินนี้ถือว่าออก
MACHINE_OUT_COOLDOWN = 10    # วิ — tag หาย นานเกินนี้ถือว่าออก
ACCUMULATED_TTL      = 30    # วิ — เก็บ tag ล่าสุดไว้ใน memory นานเท่าไหร่ (สำหรับ on_machine)
ON_MACHINE_RETRY_DELAY = 10  # วิ — Node ตอบ error / ต่อไม่ได้ → รอเท่านี้ก่อนลอง tag เดิมใหม่
SEND_RETRY_DELAY       = 10  # วิ — A7 / A6 / A2 ส่งไม่สำเร็จ → เข้าคิว ลองใหม่ทุกเท่านี้
PALLET_LOOKUP_RETRY    = 10  # วิ — pallet: /lot-by-tag พลาด → ลอง tag เดิมใหม่หลังเท่านี้

ON_MACHINE_STAY        = 2  # วิ — on_machine: ต้องอ่านเจอต่อเนื่องนานเท่านี้ก่อนนับว่าขึ้นเครื่อง (กันอ่านชนถาดที่ถือผ่าน / เครื่องข้างๆ)
ON_MACHINE_LOST        = 2  # วิ — อ่านหลุดนานกว่านี้ = เริ่มนับใหม่
COMPLETED_DONE_TTL     = 600 # วิ — completed: tag ที่ทำเสร็จแล้ว ไม่ยิง /completed ซ้ำภายในเวลานี้ (ถาดวางกองค้างหน้า reader)
COMPLETED_RETRY_DELAY  = 30  # วิ — completed: NOT_ON_MACHINE → ลองใหม่หลังเท่านี้

PROCESS_MAPPING = {
    'washing':    {'process_code': '1201'},
    'on_machine': {'process_code': '1520'},
    'completed':  {'process_code': '1520'},
}
READER_PROCESS_CODE = PROCESS_MAPPING.get(READER_TYPE, {}).get('process_code', '')

# NODE_URL = "http://localhost:2002/api/rfid"
NODE_URL = "http://10.128.17.252:2002/api/rfid"

# ===== STATE =====
reader_state = {
    "connected":         False,
    "ip":                READER_IP,
    "port_handle":       -1,
    "last_tags":         [],
    "new_tag":           None,
    "on_machine_active": True,
}

# on_machine tracking
current_qty              = 0
tag_qty                  = {}   # {tag: qty}
tag_barcode              = {}   # {tag: barcode}
tag_part_no              = {}   # {tag: part_no}
tag_rp                   = {}   # {tag: rw_diameter}
tags_on_machine          = {}   # {tag: timestamp} — tag ที่อยู่หน้า reader
rejected_tags            = set()  # tag ที่ถูก reject (part ไม่ตรง)
tags_disappeared_machine = {}   # {tag: timestamp} — รอ cooldown ก่อน out
lot_checked              = set()  # barcode ที่ส่ง A6 checking ไปแล้วในรอบนี้
on_machine_retry_after   = {}   # {tag: timestamp} — Node ตอบ error → ห้ามลองใหม่ก่อนเวลานี้
tag_dwell_start          = {}   # {tag: timestamp} — เริ่มอ่านเจอต่อเนื่องตั้งแต่เมื่อไร

# pallet tracking
tags_on_pallet           = {}   # {tag: timestamp}
tags_disappeared_pallet  = {}   # {tag: timestamp}
lot_tray_count           = {}   # {barcode: tray_counter}
lot_tags                 = {}   # {barcode: set of tags}
lot_confirmed_time       = {}   # {barcode: timestamp} — รอ PALLET_IN_COOLDOWN
lot_confirmed            = set()  # barcode ที่ส่ง pallet-in แล้ว
pallet_lookup_retry_after = {}  # {tag: timestamp} — /lot-by-tag พลาด → ห้ามลองใหม่ก่อนเวลานี้

send_retry = {}

scanning    = False
scan_thread = None

# lock กัน 2 thread ยิงคำสั่ง DLL ลง port_handle เดียวกันพร้อมกัน (ทำให้ reader หลุด Communication error)
reader_lock = threading.Lock()

# ===== ALARM =====
alarm_active = False

def alarm_loop():
    """เสียง beep วนซ้ำตราบที่ alarm_active = True"""
    while alarm_active:
        winsound.Beep(2000, 500)
        time.sleep(0.5)

def alarm_status_loop():
    """print สถานะ alarm เป็น 0/1 ต่อเนื่องตลอดเวลา (สำหรับ debug)"""
    while True:
        time.sleep(5)

def start_alarm():
    """เปิด alarm — beep + relay on → PLC สั่งลำโพง"""
    global alarm_active
    if not alarm_active:
        alarm_active = True
        threading.Thread(target=alarm_loop, daemon=True).start()
        with reader_lock:
            set_relay(0x01, reader_state["port_handle"])

def stop_alarm():
    """ปิด alarm — relay off (ยิง DLL เฉพาะตอน alarm เคย active จริง กัน set_relay รัวทุก loop จนชนกับ inventory_g2)"""
    global alarm_active
    if alarm_active:
        alarm_active = False
        with reader_lock:
            set_relay(0x00, reader_state["port_handle"])


# ===== SEND + RETRY QUEUE (A7 / A6 / A2) =====
def post_node(path, payload):
    """ยิง Node แล้วคืน (status, detail)
    'OK'       — Node ตอบ 2xx
    'NOT_SENT' — มั่นใจว่า Node ไม่ได้ทำ: ต่อไม่ติด / Node ตอบ error (Node ยิง AS400 หลังงานของตัวเองสำเร็จเท่านั้น)
    'UNKNOWN'  — ส่งไปแล้วแต่รอคำตอบไม่ทัน (timeout) → Node อาจทำไปแล้ว
    """
    try:
        res = httpx.post(f"{NODE_URL}{path}", json=payload, timeout=5)
    except (httpx.ConnectError, httpx.ConnectTimeout) as ex:
        return "NOT_SENT", f"connect: {ex}"
    except Exception as ex:
        return "UNKNOWN", f"{type(ex).__name__}: {ex}"
    if 200 <= res.status_code < 300:
        return "OK", ""
    return "NOT_SENT", f"HTTP {res.status_code}"


def send_or_queue(key, path, payload, retry_unknown, tags=()):
    """ส่งทันที · ไม่สำเร็จ → เข้าคิว send_retry
    retry_unknown=True เฉพาะ endpoint ที่ปลายทางกันซ้ำเองได้ (A2: as400.js เช็ค ALREADY_OUT)
    tags = tag ของถาดที่เป็นเจ้าของ event (ใช้ยกเลิก OUT ที่ค้างคิว เมื่อถาดกลับมาหน้า reader)
    """
    status, detail = post_node(path, payload)
    if status == "OK":
        return
    if status == "UNKNOWN" and not retry_unknown:
        return
    send_retry[key] = {"path": path, "payload": payload, "at": time.time() + SEND_RETRY_DELAY,
                       "retry_unknown": retry_unknown, "tries": 1, "tags": set(tags)}


def cancel_out_if_back(kind, present_tags):
    """OUT (A7 / A2) ที่ค้างคิว แต่ถาดกลับมาอยู่หน้า reader แล้ว → ยกเลิก
    ต้องเรียกก่อน flush_send_retry — ไม่งั้นรอบที่ถาดกลับมาพอดี flush จะส่ง OUT ออกไปก่อนรู้ว่าถาดกลับมา
    (OUT ไม่เคยถึง AS400 → AS400 ยังเห็น IN อยู่ = ตรงกับความจริง)
    """
    for key, item in list(send_retry.items()):
        if key[0] == kind and item.get("tags") and (item["tags"] & present_tags):
            send_retry.pop(key, None)


def flush_send_retry():
    """ลองส่งรายการในคิวที่ถึงเวลาแล้ว — เรียกจาก loop ของ on_machine / pallet ทุกรอบ"""
    now = time.time()
    for key, item in list(send_retry.items()):
        if now < item["at"]:
            continue
        status, detail = post_node(item["path"], item["payload"])
        item["tries"] += 1
        if status == "OK":
            send_retry.pop(key, None)
        elif status == "UNKNOWN" and not item["retry_unknown"]:
            send_retry.pop(key, None)
        else:
            item["at"] = time.time() + SEND_RETRY_DELAY


# ===== SCAN LOOP — register / washing =====
def scan_loop():
    """Loop หลักสำหรับ reader type: register และ washing
    scan ทุก 1 วิ ส่ง event ไป Node.js ทันทีที่เห็น tag ใหม่
    """
    global scanning
    seen_tags = {}

    while scanning:
        try:
            with reader_lock:
                tags = inventory_g2(reader_state["port_handle"])
            now  = time.time()
            acc  = reader_state.get("accumulated_tags", {})
            for tag in tags:
                acc[tag] = now
            acc = {t: ts for t, ts in acc.items() if now - ts < ACCUMULATED_TTL}
            reader_state["accumulated_tags"] = acc
            reader_state["last_tags"]        = list(acc.keys())
            now = time.time()

            if READER_TYPE == "register":
                for tag in tags:
                    if now - seen_tags.get(tag, 0) >= COOLDOWN:
                        seen_tags[tag] = now
                        reader_state["new_tag"] = tag
                seen_tags = {k: v for k, v in seen_tags.items() if now - v < COOLDOWN}

            elif READER_TYPE == "washing":
                for tag in tags:
                    if now - seen_tags.get(tag, 0) >= COOLDOWN:
                        seen_tags[tag] = now
                        reader_state["new_tag"] = tag
                        try:
                            httpx.post(f"{NODE_URL}/washing", json={
                                "tag_id":       tag,
                                "location":     READER_PALLET_LOCATION,
                                "process_code": READER_PROCESS_CODE,
                            }, timeout=5)
                        except Exception:
                            pass   # Node ไม่ตอบ → รอบหน้า (หลัง COOLDOWN) อ่านเจอก็ส่งใหม่
                seen_tags = {k: v for k, v in seen_tags.items() if now - v < COOLDOWN}

        except Exception as ex:
            print(f"[{time.strftime('%H:%M:%S')}] Reader disconnected: {ex}")
            reader_state["connected"]   = False
            reader_state["last_tags"]   = []
            reader_state["port_handle"] = -1
            scanning = False
            return
        time.sleep(0.5)


# ===== SCAN LOOP — on_machine =====
def scan_loop_on_machine():
    """Loop สำหรับ reader type: on_machine
    - tag อยู่ต่อเนื่อง ON_MACHINE_STAY วิ → validate part กับ machine API → update DB → Node ส่ง A5 (move in) ครั้งเดียวต่อถาด
    - lot ครบ → Node ส่ง A6 checking เอง
    - tag ออกเกิน cooldown → ลด qty ที่แสดงผลเท่านั้น
    - part ไม่ตรง → alarm
    """
    global tags_on_machine, rejected_tags, current_qty, tag_qty, lot_checked
    global rejected_details 
    if 'rejected_details' not in globals():
        rejected_details = {}
    while True:
        # ส่ง A7 / A6 ที่ค้างในคิว — ทำแม้ reader หลุด เพราะเป็นการคุยกับ Node ไม่ใช่ reader
        try:
            cancel_out_if_back("A7", set(reader_state.get("accumulated_tags", {}).keys()))
            flush_send_retry()
        except Exception as ex:
            print(f"[send_retry] error: {ex}")

        if not reader_state["connected"]:
            time.sleep(1)
            continue

        if reader_state["on_machine_active"]:
            try:
                current_tags = set(reader_state["last_tags"])
                now          = time.time()

                # tag กลับมาก่อน cooldown → ยกเลิก out
                returned_tags = set(tags_disappeared_machine.keys()) & current_tags
                for tag in returned_tags:
                    tags_disappeared_machine.pop(tag, None)
                    tags_on_machine[tag] = now

                # tag ใหม่เข้ามา
                accumulated_tags = set(reader_state.get("accumulated_tags", {}).keys())
                new_tags = accumulated_tags - set(tags_on_machine.keys()) - rejected_tags

                # dwell — tag ต้องถูกอ่านเจอต่อเนื่อง ON_MACHINE_STAY วิ ก่อน (กัน A5 / alarm จากถาดที่แค่ผ่าน)
                acc_ts = dict(reader_state.get("accumulated_tags", {}))   # {tag: เวลาที่อ่านเจอล่าสุด}
                for t, last_seen in acc_ts.items():
                    if now - last_seen > ON_MACHINE_LOST:
                        tag_dwell_start.pop(t, None)          # อ่านหลุดนาน → เริ่มนับใหม่
                    elif t not in tag_dwell_start:
                        tag_dwell_start[t] = last_seen
                for t in [t for t in tag_dwell_start if t not in acc_ts]:
                    tag_dwell_start.pop(t, None)
                new_tags = {t for t in new_tags
                            if t in tag_dwell_start and now - tag_dwell_start[t] >= ON_MACHINE_STAY}

                # tag ที่เพิ่งพลาด ยังไม่ถึงเวลาลองใหม่ → ข้ามไปก่อน
                for t in [t for t, ts in on_machine_retry_after.items() if now >= ts]:
                    on_machine_retry_after.pop(t, None)
                new_tags = new_tags - set(on_machine_retry_after.keys())
                for tag in new_tags:
                    # A7 ค้างคิวจาก Python ตัวเก่า แต่ถาดกลับขึ้นเครื่อง → ยกเลิก
                    send_retry.pop(("A7", tag), None)
                    try:
                        # เช็ค event ล่าสุดของ tag · Node error → ลองใหม่ทีหลัง (ไม่เดาว่าเป็น tag ใหม่ กันส่ง A5 ซ้ำ)
                        check_res  = httpx.get(f"{NODE_URL}/last-on-machine-event/{tag}", timeout=5)
                        if check_res.status_code != 200:
                            on_machine_retry_after[tag] = time.time() + ON_MACHINE_RETRY_DELAY
                            continue
                        last_event = check_res.json().get("event_type", "")
                        if last_event == "ON_MACHINE_IN":
                            # เคยขึ้นเครื่องแล้ว → แค่คืนค่า qty ที่แสดง ไม่ส่ง AS400 ซ้ำ
                            tags_disappeared_machine.pop(tag, None)
                            tags_on_machine[tag] = now
                            try:
                                lot_res  = httpx.get(f"{NODE_URL}/lot-by-tag/{tag}", timeout=5)
                                lot_data = lot_res.json()
                                qty      = lot_data.get("data", {}).get("tray_qty", 0)
                                tag_qty[tag]     = int(qty or 0)
                                tag_barcode[tag] = lot_data.get("data", {}).get("barcode")
                                tag_part_no[tag] = lot_data.get("data", {}).get("part_no")
                                tag_rp[tag]      = lot_data.get("data", {}).get("rw_diameter")
                                current_qty     += int(qty or 0)
                            except:
                                pass
                            continue

                        res = httpx.post(f"{NODE_URL}/on-machine", json={
                            "tag_id":       tag,
                            "location":     READER_PALLET_LOCATION,
                            "process_code": READER_PROCESS_CODE,
                        }, timeout=5)

                        result = res.json().get("result")
                        if result == "PART_MISMATCH":
                            try:
                                lot_res          = httpx.get(f"{NODE_URL}/lot-by-tag/{tag}", timeout=5)
                                lot_data         = lot_res.json()
                                mismatch_barcode = lot_data.get("data", {}).get("barcode", "")
                                mismatch_part    = lot_data.get("data", {}).get("part_no", "")
                            except:
                                mismatch_barcode = ""
                                mismatch_part    = ""
                            rejected_tags.add(tag)
                            rejected_details[tag] = (mismatch_barcode, mismatch_part)
                            all_bad_barcodes = list(set(val[0] for val in rejected_details.values() if val[0]))
                            all_bad_parts = list(set(val[1] for val in rejected_details.values() if val[1]))
                            joined_barcodes = ", ".join(all_bad_barcodes)
                            reader_state["alarm"]         = True
                            reader_state["alarm_tag"]     = tag
                            reader_state["alarm_barcode"] = ", ".join(all_bad_barcodes)
                            reader_state["alarm_part"]    = ", ".join(all_bad_parts)
                            start_alarm()
                        elif result in ("LOT_NOT_READY", "NOT_WASHED", "NOT_FOUND"):
                            try:
                                lot_res          = httpx.get(f"{NODE_URL}/lot-by-tag/{tag}", timeout=5)
                                lot_data         = lot_res.json()
                                mismatch_barcode = lot_data.get("data", {}).get("barcode", "")
                                mismatch_part    = lot_data.get("data", {}).get("part_no", "")
                            except:
                                mismatch_barcode = ""
                                mismatch_part    = ""
                            rejected_tags.add(tag)
                            rejected_details[tag] = (mismatch_barcode, mismatch_part)
                            all_bad_barcodes = list(set(val[0] for val in rejected_details.values() if val[0]))
                            all_bad_parts    = list(set(val[1] for val in rejected_details.values() if val[1]))
                            reader_state["alarm"]         = True
                            reader_state["alarm_tag"]     = tag
                            reader_state["alarm_barcode"] = ", ".join(all_bad_barcodes)
                            reader_state["alarm_part"]    = ", ".join(all_bad_parts)
                            start_alarm()
                        # ALREADY_ON_MACHINE = ถาดขึ้นเครื่องไปแล้ว (Node ไม่ส่ง A5 ซ้ำ) → นับ qty แสดงผลเหมือน OK
                        elif result in ("OK", "LOT_ON_MACHINE", "ALREADY_ON_MACHINE"):
                            reader_state["alarm"] = False
                            stop_alarm()
                            tags_on_machine[tag] = now
                            raw_qty  = 0
                            lot_data = {}
                            try:
                                lot_res  = httpx.get(f"{NODE_URL}/lot-by-tag/{tag}", timeout=5)
                                lot_data = lot_res.json()
                                raw_qty  = lot_data.get("data", {}).get("tray_qty", 0)
                            except:
                                pass

                            tray_qty_val     = raw_qty[0] if isinstance(raw_qty, list) else int(raw_qty or 0)
                            tag_qty[tag]     = tray_qty_val
                            tag_barcode[tag] = lot_data.get("data", {}).get("barcode") if lot_data else None
                            tag_part_no[tag] = lot_data.get("data", {}).get("part_no") if lot_data else None
                            tag_rp[tag]      = lot_data.get("data", {}).get("rw_diameter") if lot_data else None
                            current_qty     += tray_qty_val
                            # A6 checking: Node ส่งเองตอน LOT_ON_MACHINE (Python ไม่ส่งแล้ว)

                        else:
                            # Node error → ยังไม่นับว่าขึ้นเครื่อง ลองใหม่ทีหลัง (A5 ยังไม่ออก ส่งซ้ำได้)
                            on_machine_retry_after[tag] = time.time() + ON_MACHINE_RETRY_DELAY

                    except Exception as ex:
                        # ต่อ Node ไม่ได้ / timeout → เว้น ON_MACHINE_RETRY_DELAY ก่อนลองใหม่
                        on_machine_retry_after[tag] = time.time() + ON_MACHINE_RETRY_DELAY

                # rejected tag ออก → stop alarm ถ้าไม่มีเหลือ
                removed_rejected = rejected_tags - current_tags
                if removed_rejected:
                    for t in removed_rejected:
                        rejected_details.pop(t, None)
                        reader_state.get("accumulated_tags", {}).pop(t, None)
                        tag_dwell_start.pop(t, None)
                    rejected_tags -= removed_rejected
                    if not rejected_tags:
                        reader_state["alarm"]         = False
                        reader_state["alarm_tag"]     = ""
                        reader_state["alarm_barcode"] = ""
                        reader_state["alarm_part"]    = ""
                        stop_alarm()
                    else:
                        all_bad_barcodes = list(set(val[0] for val in rejected_details.values() if val[0]))
                        all_bad_parts = list(set(val[1] for val in rejected_details.values() if val[1]))
                        reader_state["alarm_barcode"] = ", ".join(all_bad_barcodes)
                        reader_state["alarm_part"]    = ", ".join(all_bad_parts)

                # tag หายออก → เริ่มนับ cooldown
                left_tags = set(tags_on_machine.keys()) - set(reader_state.get("accumulated_tags", {}).keys())
                for tag in left_tags:
                    if tag not in tags_disappeared_machine:
                        tags_disappeared_machine[tag] = now
                    tags_on_machine.pop(tag, None)

                # tag หายเกิน cooldown → ลด qty ที่แสดง (A7 ส่งที่ completed)
                for tag, t in list(tags_disappeared_machine.items()):
                    if now - t >= MACHINE_OUT_COOLDOWN:
                        qty_removed = tag_qty.pop(tag, 0)
                        barcode     = tag_barcode.get(tag)
                        tag_part_no.pop(tag, None)
                        tag_rp.pop(tag, None)
                        current_qty = max(current_qty - qty_removed, 0)
                        tags_disappeared_machine.pop(tag, None)

                        # ถ้า tag ทั้งหมดของ lot ออกไปหมด → reset A6 tracking
                        if barcode:
                            tags_of_lot = {t for t, b in tag_barcode.items() if b == barcode and t in tags_on_machine}
                            if len(tags_of_lot) == 0:
                                lot_checked.discard(barcode)
                                send_retry.pop(("A6", barcode), None)

                        tag_barcode.pop(tag, None)

                if not (current_tags - set(tags_on_machine.keys())):
                    stop_alarm()

            except Exception as ex:
                print(f"[scan_loop_on_machine] error: {ex}")

        time.sleep(0.5)


# ===== SCAN LOOP — completed =====
def scan_loop_completed():
    """Loop สำหรับ reader type: completed
    scan tag → ส่ง completed event ทีละ tray
    """
    seen_tags = {}
    # จำว่า tag ไหนจบแล้ว ไม่ยิงซ้ำ COMPLETED_DONE_TTL วิ · NOT_ON_MACHINE เว้น COMPLETED_RETRY_DELAY วิ · ไม่ sleep
    skip_until = {}   # {tag: timestamp} — ห้ามยิง /completed ก่อนเวลานี้

    while True:
        if not reader_state["connected"]:
            time.sleep(1)
            continue

        try:
            tags = reader_state["last_tags"]
            now  = time.time()

            for tag in tags:
                if now < skip_until.get(tag, 0):
                    continue
                if now - seen_tags.get(tag, 0) >= COOLDOWN:
                    seen_tags[tag] = now
                    try:
                        res    = httpx.post(f"{NODE_URL}/completed", json={"tag_id": tag}, timeout=5)
                        result = res.json().get("result")
                        if result == "LOT_COMPLETED":
                            skip_until[tag] = time.time() + COMPLETED_DONE_TTL
                        elif result == "NOT_ON_MACHINE":
                            skip_until[tag] = time.time() + COMPLETED_RETRY_DELAY
                        elif result == "OK":
                            skip_until[tag] = time.time() + COMPLETED_DONE_TTL
                    except Exception:
                        pass   # Node ไม่ตอบ → ลองใหม่หลัง COOLDOWN

            seen_tags = {k: v for k, v in seen_tags.items() if now - v < COOLDOWN}
            skip_until = {k: v for k, v in skip_until.items() if now < v}

        except Exception as ex:
            print(f"[scan_loop_completed] error: {ex}")

        time.sleep(0.5)


# ===== SCAN LOOP — pallet =====
PALLET_SEND_RETRY = 10   # วิ — ส่ง /pallet ไม่สำเร็จ → ลอง tag เดิมใหม่หลังเท่านี้
# ผลที่ SP lot_update_location ตอบชัดเจน → ถือว่า tag นี้จบ ไม่ส่งซ้ำระหว่างยังอยู่หน้า reader
PALLET_DONE_RESULTS = ("OK", "DUPLICATE_LOCATION", "NOT_READY", "TRAY_NOT_COMPLETE")

def scan_loop_pallet():
    """Loop สำหรับ reader type: pallet
    - เห็น tag ใหม่ → ส่ง /pallet ทันที ไม่ต้องรอครบ lot
      SP lot_update_location: tag แรกของ lot อัปทั้ง lot + Node ส่ง A1 (ครั้งเดียว)
                              tag ที่เหลือได้ DUPLICATE_LOCATION → ไม่ส่งอะไร
    - tag หาย → ไม่ทำอะไร (A2 ย้ายไปส่งที่ washing)
    - ส่งพลาด (ต่อไม่ได้ / Node error / SP error) → ลองใหม่หลัง PALLET_SEND_RETRY
      ส่งซ้ำปลอดภัย: SP ทำไปแล้ว = DUPLICATE_LOCATION → ไม่มี A1 ซ้ำ
    """
    sent        = {}   # {tag: timestamp} — tag ที่ส่งจบแล้ว ขณะยังอยู่หน้า reader
    retry_after = {}   # {tag: timestamp} — tag ที่ส่งพลาด ห้ามลองใหม่ก่อนเวลานี้

    while True:
        if not reader_state["connected"]:
            time.sleep(1)
            continue

        try:
            current_tags = set(reader_state["last_tags"])
            now          = time.time()

            # tag ออกจากระยะแล้ว → ลืม (กลับมาใหม่ = ส่งใหม่ SP ตัดสินเองว่าซ้ำหรือย้าย pallet)
            for t in [t for t in sent if t not in current_tags]:
                sent.pop(t, None)
            for t in [t for t, ts in retry_after.items() if now >= ts or t not in current_tags]:
                retry_after.pop(t, None)

            for tag in current_tags - set(sent) - set(retry_after):
                try:
                    res    = httpx.post(f"{NODE_URL}/pallet",
                        json={"tag_id": tag, "location": READER_PALLET_LOCATION}, timeout=5)
                    result = res.json().get("result")
                    if res.status_code == 200 and result in PALLET_DONE_RESULTS:
                        sent[tag] = now
                    else:
                        retry_after[tag] = time.time() + PALLET_SEND_RETRY
                except Exception as ex:
                    retry_after[tag] = time.time() + PALLET_SEND_RETRY

        except Exception as ex:
            print(f"[scan_loop_pallet] error: {ex}")

        time.sleep(0.5)


# ===== CONNECT & RECONNECT =====
def connect_reader():
    """เชื่อมต่อ reader ผ่าน TCP และเริ่ม scan_loop"""
    global scanning, scan_thread
    for _ in range(3):
        try:
            close_net_port(reader_state["port_handle"])
        except:
            pass
        time.sleep(1)

    reader_state["port_handle"] = -1
    time.sleep(2)

    result, handle = open_net_port(READER_IP, READER_PORT_TCP)
    if result == 0:
        reader_state["port_handle"] = handle
        with reader_lock:
            set_power(READER_POWER, handle)
        reader_state["connected"] = True
        scanning    = True
        scan_thread = threading.Thread(target=scan_loop, daemon=True)
        scan_thread.start()
        print(f"[{time.strftime('%H:%M:%S')}] [OK] [{READER_TYPE}] Connected: {READER_IP}")
    else:
        reader_state["connected"]   = False
        reader_state["port_handle"] = -1
        print(f"[{time.strftime('%H:%M:%S')}] [FAIL] Connect failed: {get_error_desc(result)}")


def reconnect_loop():
    """วน reconnect ถ้า reader หลุด exit หลัง fail 3 ครั้ง → start_rfid.py จะ restart"""
    fail_count = 0
    while True:
        if not reader_state["connected"]:
            print(f"[{time.strftime('%H:%M:%S')}] Reconnecting...")
            connect_reader()
            if not reader_state["connected"]:
                fail_count += 1
                if fail_count >= 3:
                    print(f"[FAIL] Too many retries → exiting")
                    os._exit(1)
            else:
                fail_count = 0
        time.sleep(5)


# ===== FASTAPI =====
@asynccontextmanager
async def lifespan(app: FastAPI):
    print(f"Starting [{READER_TYPE}] @ {READER_IP} (index={READER_INDEX})")
    threading.Thread(target=reconnect_loop, daemon=True).start()
    threading.Thread(target=alarm_status_loop, daemon=True).start()
    if READER_TYPE == "on_machine":
        threading.Thread(target=scan_loop_on_machine, daemon=True).start()
    if READER_TYPE == "pallet":
        threading.Thread(target=scan_loop_pallet, daemon=True).start()
    if READER_TYPE == "completed":
        threading.Thread(target=scan_loop_completed, daemon=True).start()
    yield
    global scanning
    scanning = False
    if reader_state["port_handle"] != -1:
        close_net_port(reader_state["port_handle"])
    print("Service stopped")


app = FastAPI(lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


# เวอร์ชันที่กำลังรันจริง: เวลาไฟล์ exe (หรือ main_dll.py ตอนรัน python) + pid + เวลาที่ process เริ่ม
# เปิด http://<server>:<port>/status เช็คได้ว่าวางทับแล้ว process ใหม่ขึ้นจริงหรือยังเป็นตัวเก่า
_RUN_FILE = sys.executable if getattr(sys, "frozen", False) else os.path.abspath(__file__)
BUILD_TIME = time.strftime("%Y-%m-%d %H:%M", time.localtime(os.path.getmtime(_RUN_FILE)))
STARTED_AT = time.strftime("%Y-%m-%d %H:%M:%S")

# @app.get("/status")
# def status():
#     unique_parts = list(set(v for v in tag_part_no.values() if v))
#     unique_rps   = list(set(v for v in tag_rp.values() if v))
#     unique_barcodes = list(set(v for v in tag_barcode.values() if v))
#     return {
#         "connected":   reader_state["connected"],
#         "ip":          reader_state["ip"],
#         "type":        READER_TYPE,
#         "location":    READER_PALLET_LOCATION,
#         "current_qty": current_qty,
#         "min_qty":     MIN_QTY,
#         "low_qty":     MIN_QTY > 0 and current_qty < MIN_QTY,
#         "parts":       unique_parts,
#         "rps":         unique_rps,
#         "barcodes":    unique_barcodes,
#         "alarm":       reader_state.get("alarm", False),
#         "alarm_tag":     reader_state.get("alarm_tag", ""),
#         "alarm_barcode": reader_state.get("alarm_barcode", ""),
#         "alarm_part":    reader_state.get("alarm_part", ""),
#         "build":         BUILD_TIME,
#         "started":       STARTED_AT,
#         "pid":           os.getpid(),
# }

from typing import Dict, Any, List

@app.get("/status")
def status() -> Dict[str, Any]:
    unique_parts = list(set(v for v in tag_part_no.values() if v))
    unique_rps   = list(set(v for v in tag_rp.values() if v))
    job_qty_map: Dict[str, int] = {}
    
    for tag in tags_on_machine.keys():
        bcode = tag_barcode.get(tag)
        if bcode:
            qty = tag_qty.get(tag, 0)
            job_qty_map[bcode] = job_qty_map.get(bcode, 0) + qty
            
    formatted_barcodes: List[Dict[str, Any]] = [
        {"barcode": k, "qty": v} for k, v in job_qty_map.items()
    ]

    return {
        "connected":     reader_state["connected"],
        "ip":            reader_state["ip"],
        "type":          READER_TYPE,
        "location":      READER_PALLET_LOCATION,
        "current_qty":   current_qty,
        "min_qty":       MIN_QTY,
        "low_qty":       MIN_QTY > 0 and current_qty < MIN_QTY,
        "parts":         unique_parts,
        "rps":           unique_rps,
        "barcodes":      formatted_barcodes, # ส่งโครงสร้างใหม่ที่บวกเลขเสร็จแล้ว
        "alarm":         reader_state.get("alarm", False),
        "alarm_tag":     reader_state.get("alarm_tag", ""),
        "alarm_barcode": reader_state.get("alarm_barcode", ""),
        "alarm_part":    reader_state.get("alarm_part", ""),
        "build":         BUILD_TIME,
        "started":       STARTED_AT,
        "pid":           os.getpid(),
    }

@app.get("/tags")
def get_tags():
    return {"tags": reader_state["last_tags"], "count": len(reader_state["last_tags"])}

@app.get("/new-tag")
def get_new_tag():
    tag = reader_state["new_tag"]
    reader_state["new_tag"] = None
    return {"tag_id": tag}

@app.get("/new-tag/washing")
def get_new_tag_washing():
    tag = reader_state["new_tag"]
    reader_state["new_tag"] = None
    return {"tag_id": tag}

@app.get("/new-tag/pallet")
def get_new_tag_pallet():
    tag = reader_state["new_tag"]
    reader_state["new_tag"] = None
    return {"tag_id": tag, "location": READER_PALLET_LOCATION}


@app.get("/restart")
def restart_reader():
    """Restart uvicorn process ของ reader ตัวนี้"""
    def do_restart():
        time.sleep(1)
        os._exit(0)   # start_rfid.py เห็น process ตาย → start ใหม่ให้เอง
    threading.Thread(target=do_restart, daemon=True).start()
    return {"result": "OK"}

@app.get("/alarm")
def get_alarm():
    return {
        "alarm":   reader_state.get("alarm", False),
        "location": READER_PALLET_LOCATION,
        "tag":     reader_state.get("alarm_tag", ""),
        "barcode": reader_state.get("alarm_barcode", ""),
        "part":    reader_state.get("alarm_part", ""),
    }

@app.get("/test-relay-on")
def test_relay_on():
    with reader_lock:
        result = set_relay(0x01, reader_state["port_handle"])
    return {"status": 1, "result": result}

@app.get("/test-relay-off")
def test_relay_off():
    with reader_lock:
        result = set_relay(0x00, reader_state["port_handle"])
    return {"status": 0, "result": result}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=CFG['port'], log_level="warning")